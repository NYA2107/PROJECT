package splay.tree;

public class Node {
	Integer id;
	String name;
	Node left,right;
	
	/**************
	 * Constructor*
	 **************/
	public Node(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

}
